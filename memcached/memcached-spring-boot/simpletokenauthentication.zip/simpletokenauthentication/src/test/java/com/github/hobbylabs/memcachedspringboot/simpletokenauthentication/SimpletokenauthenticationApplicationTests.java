package com.github.hobbylabs.memcachedspringboot.simpletokenauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpletokenauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
